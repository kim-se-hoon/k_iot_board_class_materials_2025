package org.example.boardback.common.enums;

public enum RoleType {
    USER,
    MANAGER,
    ADMIN
}
